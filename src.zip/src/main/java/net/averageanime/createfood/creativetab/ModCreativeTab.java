package net.averageanime.createfood.creativetab;

import com.simibubi.create.AllCreativeModeTabs;
import com.tterrag.registrate.util.entry.RegistryEntry;
import it.unimi.dsi.fastutil.objects.ReferenceArrayList;
import it.unimi.dsi.fastutil.objects.ReferenceLinkedOpenHashSet;
import net.averageanime.createfood.fluid.ModFluids;
import net.averageanime.createfood.item.ModItems;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fluids.ForgeFlowingFluid;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
import net.averageanime.createfood.CreateFood;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import static net.averageanime.createfood.CreateFood.REGISTRATE;

public class ModCreativeTab {

    private static final DeferredRegister<CreativeModeTab> REGISTER;
    public static final RegistryObject<CreativeModeTab> CREATIVE_TAB;
    public static final RegistryObject<CreativeModeTab> FLUID_TAB;

    public ModCreativeTab() {}

    public static void register(IEventBus modEventBus) {
        REGISTER.register(modEventBus);
    }

    static {
        REGISTER = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CreateFood.ID);
        CREATIVE_TAB = REGISTER.register("base", () ->
            CreativeModeTab.builder()
                    .title(Component.literal("Create: Food"))
                    .withTabsBefore(AllCreativeModeTabs.BASE_CREATIVE_TAB.getKey(), AllCreativeModeTabs.PALETTES_CREATIVE_TAB.getKey())
                    .icon(() -> new ItemStack(ModItems.BREAKFAST_PLATE.get()))
                    .displayItems((params, output) -> {
                        List<Item> items = new LinkedList<>();
                        items.addAll(collectItems());
                        items.addAll(collectBlocks());
                        filterAndOutput(output, items);
                    })
                    .build()
        );
        FLUID_TAB = REGISTER.register("fluid", () ->
            CreativeModeTab.builder()
                    .title(Component.literal("Create: Food Fluids"))
                    .withTabsBefore(CREATIVE_TAB.getKey())
                    .icon(() -> new ItemStack(ModFluids.CUSTARD.getBucket().orElse(Items.AIR)))
                    .displayItems((params, output) -> filterAndOutput(output, collectFluids()))
                    .build()
        );
    }

    private static List<Item> collectBlocks() {
        List<Item> items = new ReferenceArrayList<>();
        for (RegistryEntry<Block> entry : REGISTRATE.getAll(Registries.BLOCK)) {
            Item item = entry.get().asItem();
            if (item != Items.AIR) {
                items.add(item);
            }
        }
        return new ReferenceArrayList<>(new ReferenceLinkedOpenHashSet<>(items));
    }

    private static List<Item> collectItems() {
        List<Item> items = new ReferenceArrayList<>();
        for (RegistryObject<Item> entry : ModItems.ITEMS.getEntries()) {
            Item item = entry.get();
            if (!(item instanceof BlockItem) && !(item instanceof BucketItem)) {
                items.add(item);
            }
        }
        return items;
    }

    @SuppressWarnings("unchecked")
    private static List<Item> collectFluids() {
        List<Item> items = new ReferenceArrayList<>();
        Iterator var3 = REGISTRATE.getAll(Registries.FLUID).iterator();
        while (var3.hasNext()) {
            RegistryEntry<ForgeFlowingFluid> entry = (RegistryEntry<ForgeFlowingFluid>) var3.next();
            try {
                ForgeFlowingFluid fluid = entry.get();
                if (fluid.getBucket() != Items.AIR && !items.contains(fluid.getBucket())) {
                    items.add(fluid.getBucket());
                }
            } catch (ClassCastException ignored) {}
        }
        return items;
    }

    private static void filterAndOutput(CreativeModeTab.Output output, List<Item> items) {
        for (Item item : items) {
            if (item.toString().contains("incomplete")) continue;
            if (item.toString().contains("guide")) continue;
            if (item.toString().contains("blaze_burner")) continue;
            if (item.toString().contains("creative_tab_icon")) continue;
            output.accept(item);
        }
    }
}
